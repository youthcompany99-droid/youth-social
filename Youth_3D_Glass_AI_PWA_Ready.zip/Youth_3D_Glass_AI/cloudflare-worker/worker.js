// Youth AI backend for Cloudflare Workers.
// Set the GEMINI_API_KEY secret in Cloudflare; never put it in app.js or HTML.
// Optional environment variable ALLOWED_ORIGIN should be your deployed Youth site origin.
export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";
    const allowed = env.ALLOWED_ORIGIN || "*";
    const corsOrigin = allowed === "*" || origin === allowed ? (allowed === "*" ? "*" : origin) : "null";
    const headers = {
      "Access-Control-Allow-Origin": corsOrigin,
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
      "Content-Type": "application/json; charset=utf-8",
      "Vary": "Origin"
    };
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers });
    const url = new URL(request.url);
    if (url.pathname !== "/api/chat") return new Response(JSON.stringify({ error: "Not found" }), { status: 404, headers });
    if (request.method !== "POST") return new Response(JSON.stringify({ error: "Use POST" }), { status: 405, headers });
    if (corsOrigin === "null") return new Response(JSON.stringify({ error: "Origin not allowed" }), { status: 403, headers });
    if (!env.GEMINI_API_KEY) return new Response(JSON.stringify({ error: "AI backend is missing GEMINI_API_KEY" }), { status: 500, headers });
    try {
      const body = await request.json();
      const message = typeof body.message === "string" ? body.message.trim().slice(0, 1500) : "";
      if (!message) return new Response(JSON.stringify({ error: "Message is required" }), { status: 400, headers });
      const history = Array.isArray(body.history) ? body.history.slice(-8) : [];
      const contents = [];
      for (const item of history) {
        if (!item || typeof item.text !== "string") continue;
        const role = item.role === "assistant" ? "model" : "user";
        contents.push({ role, parts: [{ text: item.text.slice(0, 1500) }] });
      }
      // Ensure latest user message is included only once.
      if (!contents.length || contents[contents.length - 1].role !== "user" || contents[contents.length - 1].parts[0].text !== message) {
        contents.push({ role: "user", parts: [{ text: message }] });
      }
      const apiResponse = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent", {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: "You are Youth AI, a friendly, respectful assistant inside the Youth social app. Help with writing, captions, ideas, learning, and everyday questions. Do not ask users for passwords, verification codes, or sensitive personal information. Be concise and honest when uncertain." }] },
          contents,
          generationConfig: { temperature: 0.8, maxOutputTokens: 700 }
        })
      });
      const data = await apiResponse.json();
      if (!apiResponse.ok) return new Response(JSON.stringify({ error: "AI provider request failed", detail: data?.error?.message || "Check API key and quota" }), { status: 502, headers });
      const reply = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
      return new Response(JSON.stringify({ reply: reply || "I couldn't generate a reply. Please try again." }), { status: 200, headers });
    } catch (error) {
      return new Response(JSON.stringify({ error: "Invalid request or AI service error" }), { status: 400, headers });
    }
  }
};
